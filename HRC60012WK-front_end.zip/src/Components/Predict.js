import {Button} from "@mui/material";

const Predict = ()=>{
    return(<>
            <Button variant="contained" color="primary" onClick={()=>{
                alert("Not Yet Working\nTo be Added in Next Release\nTry Other things by then");
            }}>Predict</Button>
        </>
    )
}
export default Predict;