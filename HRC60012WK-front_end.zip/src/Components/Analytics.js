import {Button} from "@mui/material";
const Analytics = ()=>{

    return(<>
            <Button variant="outlined" color="primary" onClick={()=>{
                alert("Not Yet Working\nTo be Added in Next Release\nTry Other things by then");
            }}>Analytics View</Button>
        </>
    )
}
export default Analytics;